import webapp2
import jinja2
from google.appengine.ext import db
from google.appengine.ext import ndb
import os
import re
import hashlib
import hmac
import random
import string
import pdf

template_dir = os.path.join(os.path.dirname(__file__), "templates")
jinja_environment = jinja2.Environment(
    loader=jinja2.FileSystemLoader(template_dir),
    autoescape=True)

USER_RE = re.compile(r"^[a-zA-Z_-]{3,20}$")
PASSWORD_RE = re.compile(r"^.{3,20}$")
EMAIL_RE = re.compile(r"^[\S]+@[\S]+\.[\S]+$")
FULL_RE = re.compile(r"^[a-zA-Z0-9_-]{3,20}$")

secret = "nooneknows"


class BaseHandler(webapp2.RequestHandler):
    def render(self, template, **kw):
        self.response.out.write(render_str(template, **kw))

def render_str(template, **params):
    t = jinja_environment.get_template(template)
    return t.render(params)


def make_secure_val(val):
    return "%s|%s" % (val, hmac.new(secret, val).hexdigest())


def check_secure_val(secure_val):
    val = secure_val.split('|')[0]
    return secure_val == make_secure_val(val)


def make_salt(length=10):
    return "".join(random.choice(string.letters) for x in xrange(length))

def make_pw_hash(pw, salt=None):
    if not salt:
        salt = make_salt()
    h = hashlib.sha256(pw + salt).hexdigest()
    return "%s#%s" % (h, salt)
                               
def valid_pw(pw, h):
    salt = h.split('#')[1]
    return h == make_pw_hash(pw, salt)

def set_cookie(handler, name, value):
    handler.response.headers.add_header("Set-Cookie", "%s=%s; Path=/" %
                                        (str(name), str(value)))


class User(db.Model):
    username = db.StringProperty(required=True)
    password = db.StringProperty(required=True)
    fullname = db.StringProperty()
    email = db.StringProperty()

def add_user(username,fullname,email, **kw):
    u = User(key_name=username, username=username, fullname = fullname, email = email, **kw)
    u.put()

def get_user(username):
    return User.get_by_key_name(username)       


class Signup(webapp2.RequestHandler):
    def get(self):
        template = jinja_environment.get_template("signup.html")
        self.response.out.write(template.render())

    def post(self):
        username = self.request.get("username")
        fullname = self.request.get("fullname")
        password = self.request.get("password")
        verify = self.request.get("verify")
        email = self.request.get("email")

        errors = {}
        
        if not self.valid_username(username):
            errors["invalid_username"] = "That's not a valid username."
            errors["username"] = username
        
        if not self.valid_password(password):
            errors["invalid_password"] = "That wasn't a valid password."
        elif not self.valid_verify(password, verify):
            errors["invalid_verify"] = "Your passwords didn't match."

        if email and not self.valid_email(email):
            errors["invalid_email"] = "That's not a valid email."

        if fullname and not self.valid_fullname(fullname):
        	errors["fullname"] = "That's not a valid fullname."

        if get_user(username):
            errors.clear()
            errors["invalid_username"] = "That user already exists"
            
        if errors:
            template = jinja_environment.get_template("signup.html")
            self.response.out.write(template.render(errors))
        else:
            add_user(username=username,fullname = fullname,email = email,password=make_pw_hash(password))
            set_cookie(self, "username", make_secure_val(username))
            self.redirect("/blog/welcome")
        
    def valid_username(self, username):
        return USER_RE.match(username)

    def valid_password(self, password):
        return PASSWORD_RE.match(password)

    def valid_verify(self, password, verify):
        """Check if password and verify same."""
        return password == verify

    def valid_email(self, email):
        return EMAIL_RE.match(email)

    def valid_fullname(self, fullname):
    	return FULL_RE.match(fullname)


class Login(BaseHandler):
    def get(self):
        template = jinja_environment.get_template("login.html")
        self.response.out.write(template.render())

    def post(self):
        username = self.request.get("username")
        password = self.request.get("password")

        errros = {}
        u = get_user(username)
        if u and valid_pw(password, u.password):
            set_cookie(self, username, make_secure_val(username))
            self.render("welcome.html",username=username)
        else:
            error = "Invalid login"
            template_values = {"error": error}
            template = jinja_environment.get_template("login.html")
            self.response.out.write(template.render(template_values))

class Logout(webapp2.RequestHandler):
    def get(self):
        set_cookie(self, "username", "")
        self.redirect("/blog/start/")

class Start(webapp2.RequestHandler):
    def get(self):
        template = jinja_environment.get_template("start.html")
        self.response.out.write(template.render())

class SearchBook(BaseHandler):
    def get(self):
        books = pdf.UserPhoto.query()
        self.render("search.html",books=books)
        

class UserSettings(webapp2.RequestHandler):
    def get(self):
        template = jinja_environment.get_template("Settings.html")
        self.response.out.write(template.render())

class Error(webapp2.RequestHandler):
    def get(self):
        template = jinja_environment.get_template("Error.html")
        self.response.out.write(template.render())



class Welcome(webapp2.RequestHandler):
    def get(self):
        c = self.request.cookies.get("username")
        username = c.split('|')[0]
        template_values = {"username": username }
        template = jinja_environment.get_template("welcome.html")
        self.response.out.write(template.render(template_values))


