import webapp2
import rot13
import signup
import blog
import pdf

class MainPage(webapp2.RequestHandler):
    def get(self):
        self.redirect('/blog/start/?')

app = webapp2.WSGIApplication([("/?", MainPage),
                               ("/blog/signup/?", signup.Signup),
                               ("/blog/login/?", signup.Login),
                               ("/blog/logout/?", signup.Logout),
                               ("/blog/welcome/?", signup.Welcome),
                               ("/blog/start/?", signup.Start),
                               ("/blog/error/?",signup.Error),
                               ("/blog/search/?",signup.SearchBook),
                               ("/blog/settings/?",signup.UserSettings),
                               ('/photo', pdf.PhotoUploadFormHandler),
                               ('/upload_photo', pdf.PhotoUploadHandler),
                               ('/view_photo/', pdf.ViewPhotoHandler),
                               ('/blog/searchisbn/?', pdf.IsbnSearch),
                               ('/blog/searchname/?', pdf.NameSearch)],
                              debug=True)

