from google.appengine.api import users
from google.appengine.ext import blobstore
from google.appengine.ext import ndb
from google.appengine.ext.webapp import template
from google.appengine.ext.webapp import blobstore_handlers
import webapp2
import jinja2
import os


template_dir = os.path.join(os.path.dirname(__file__), "templates")
jinja_environment = jinja2.Environment(
    loader=jinja2.FileSystemLoader(template_dir),
    autoescape=True)

class BaseHandler(webapp2.RequestHandler):
    def render(self, template, **kw):
        self.response.out.write(render_str(template, **kw))


    def render_template(self, view_filename, params=None):
        if not params:
            params = {}
            user = "Admin"
            params['user'] = user
            path = os.path.join(os.path.dirname(__file__), 'templates', view_filename)
            self.response.out.write(template.render(path, params))


def render_str(template, **params):
    t = jinja_environment.get_template(template)
    return t.render(params)

class UserPhoto(ndb.Model):
    blob_key = ndb.BlobKeyProperty()
    ISBN_Number = ndb.StringProperty(required=True)
    Book_Name = ndb.StringProperty(required=True)

class IsbnSearch(BaseHandler):
    def post(self):
        isbn = self.request.POST.get('isbn')
        books = UserPhoto.query().filter(UserPhoto.ISBN_Number == isbn)        
        if not books:
            self.redirect("/blog/error/")
            print "error"
        else:
            self.render("searchISBN.html", books=books)

class NameSearch(BaseHandler):
    def post(self):
        name = self.request.POST.get('name')
        books = UserPhoto.query().filter(UserPhoto.Book_Name == name)
        if not books:
            self.redirect("/blog/error/")
            print "error"
        else:
            self.render("nameSearch.html", books=books)


class PhotoUploadFormHandler(webapp2.RequestHandler):
    def get(self):
        upload_url = blobstore.create_upload_url('/upload_photo')
        self.response.out.write("""
        <html>
            <body>
            <form action="{0}" method="POST" enctype="multipart/form-data">
                  ISBN Number:<br>
                  <input type="text" name="firstname"><br>
                  Book Name:<br>
                  <input type="text" name="lastname"> <br>
                  Upload File: <br> <input type="file" name="file"><br>
                  <input type="submit" name="submit" value="Submit">
            </form>
            </body>
        </html>""".format(upload_url))

    def post(self):
        upload = self.get_uploads()[0]
        user_photo = UserPhoto(
            blob_key = upload.key(),
            ISBN_Number = self.request.POST.get('firstname'), 
            Book_Name = self.request.POST.get('lastname'))
        user_photo.put()
        self.response.write("Success")  #Redirect to same to same page.

class PhotoUploadHandler(blobstore_handlers.BlobstoreUploadHandler):
    def get(self):
        upload_files = self.get_uploads('file')    
        upload = upload_files[0]        
        user_photo = UserPhoto(
            blob_key = upload.key(),
            ISBN_Number = self.request.get.get('firstname'), 
            Book_Name = self.request.get.get('lastname'))
        user_photo.put()
        self.response.write("Success")


    def post(self):
        upload_files = self.get_uploads('file')    
        upload = upload_files[0] 
        user_photo = UserPhoto(
            blob_key = upload.key(),
            ISBN_Number = self.request.POST.get('firstname'), 
            Book_Name = self.request.POST.get('lastname'))
        user_photo.put()
        self.response.write("Success")
       


class ViewPhotoHandler(blobstore_handlers.BlobstoreDownloadHandler):
    def get(self, resource):
        if not blobstore.get(resource):
            self.error(404)
        else:
            self.response.write(resource)

    def get(self):
        resource2 = self.request.GET.get('resource')
        self.send_blob(resource2)